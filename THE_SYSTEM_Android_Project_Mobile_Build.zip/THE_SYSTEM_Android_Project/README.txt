THE SYSTEM — Android project

This project wraps the upgraded standalone HTML app in a lightweight Android WebView app.

BUILD AN APK (requires a computer with Android Studio and internet for the first Gradle sync):
1. Extract this ZIP.
2. Open Android Studio.
3. Choose File > Open and select the extracted THE_SYSTEM_Android_Project folder.
4. Allow Gradle sync and install the Android SDK Platform 35 if prompted.
5. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
6. When the build finishes, click Locate. The APK is normally at:
   app/build/outputs/apk/debug/app-debug.apk
7. Transfer app-debug.apk to your Android phone and install it. You may need to allow
   installation from that file manager/browser when Android asks.

NOTES:
- App name: THE SYSTEM
- Application ID: com.thesystem.app
- Minimum Android version: Android 6.0 (API 23)
- Your app data is stored locally in the app's WebView storage on that device.
- Export a JSON backup from THE SYSTEM before uninstalling or changing devices.
- This is a debug APK build setup. A signed release APK can be created in Android Studio
  using Build > Generate Signed Bundle / APK.
