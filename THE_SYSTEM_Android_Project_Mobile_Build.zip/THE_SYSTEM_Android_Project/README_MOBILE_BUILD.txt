BUILD THE SYSTEM APK USING ONLY YOUR ANDROID PHONE + WI-FI

This project includes a GitHub Actions workflow that builds the APK in the cloud.
You do not need Android Studio or a computer. You do need a GitHub account.

1. Download and extract this ZIP on your phone (Files app > Downloads > ZIP > Extract).
2. In your browser, sign in to https://github.com/ and create a new repository named THE-SYSTEM-APK.
   Choose Public or Private; either is fine. Do not add a README, .gitignore, or license.
3. Open the new empty repository. Choose Add file > Upload files.
4. Upload the CONTENTS of the extracted THE_SYSTEM_Android_Project folder, including the hidden
   .github folder. The .github/workflows/build-apk.yml file is essential.
   If your phone's file picker hides .github, use GitHub's web upload page in desktop mode or
   a ZIP-aware file manager that can show hidden files.
5. Commit the upload to the main branch.
6. Open the repository's Actions tab. Select "Build THE SYSTEM APK" and tap Run workflow
   if it has not started automatically. Wait for the workflow to finish successfully.
7. Open the completed workflow run. Under Artifacts, download THE-SYSTEM-debug-apk.
   Extract the downloaded artifact ZIP to get app-debug.apk.
8. Tap app-debug.apk to install. If Android asks, allow your browser or file manager to
   install unknown apps, then return and install it.

The APK is a debug build for personal installation. It is not published to Google Play.
Keep a JSON backup of your game progress before uninstalling or moving the app.
